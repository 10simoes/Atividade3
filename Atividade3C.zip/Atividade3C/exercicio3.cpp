#include<stdio.h>

main(){
	
	float altura;
	
	printf("\nDigite sua altura: ");
	scanf("%f",&altura);
	
	if(altura>=1.8){
		
		printf("\nVoce e maior ou igual a 1.8 metros");
	}else
	printf("\nMenor que 1.8 metros");
}
