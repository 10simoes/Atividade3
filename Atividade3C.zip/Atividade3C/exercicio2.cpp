#include<stdio.h>

main(){
	
	float salario;
	
	printf("Digite seu salario: ");
	scanf("%f",&salario);
	
	
	if(salario>= 1302){
		
		printf ("\n Ganha mais ou igual que o salario minimo");
	}else
	printf("Ganha menos que o salario minimo");
}
