#include<stdio.h>

main(){

    int idade;

    printf("\nDigite a sua idade: ");
    scanf("%d",&idade);

    if(idade>=18){

        printf("\nVoce e maior de idade");
    }else{
        printf("\nVoce e menor de idade");
    }
}
