#include<stdio.h>

main(){
	
	float peso;
	
	printf("\nDigite seu peso: ");
	scanf("%f",&peso);
	
	
	if(peso>=60){
		
		printf("\nSeu peso e maior ou igual a 60kg");
	}else
	printf("\n Seu peso e menor que 60kg");
	
}
